/*
 * Copyright (c) 2006-2008 Hyperic, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.hyperic.sigar;

import org.hyperic.sigar.ptql.ProcessFinder;

/**
 * Provide multi process cpu metrics.
 */
public class MultiProcCpu extends ProcCpu {

    private long pid;
    private int nproc = 0;


    static synchronized MultiProcCpu get(Sigar sigar, String query)
                throws SigarException {

        MultiProcCpu cpu = new MultiProcCpu();
        cpu.pid = query.hashCode(); //for equals()

        cpu.total = 0;
        cpu.user  = 0;
        cpu.sys   = 0;
        cpu.percent = 0.0D;

        long[] pids = ProcessFinder.find(sigar, query);
        cpu.nproc = pids.length;

        for (int i=0; i<pids.length; i++) {
            try {
                ProcCpu procCpu = sigar.getProcCpu(pids[i]);
                cpu.total += procCpu.getTotal();
                cpu.user += procCpu.getUser();
                cpu.sys += procCpu.getSys();
                cpu.percent += procCpu.getPercent();
            } catch (SigarException e) {
                //process may have gone away or EPERM
                continue;
            }
        }

        return cpu;
    }

    /**
     * @return Processes CPU usage percentage.
     */
    public double getPercent() {
        return this.percent;
    }

    /**
     * @return Number of processes matched by query.
     */
    public int getProcesses() {
        return this.nproc;
    }

    /**
     * @return Pid of the process.
     */
    public int hashCode() {
        return (int)this.pid;
    }

    public boolean equals(Object cpu) {
        if (!(cpu instanceof MultiProcCpu)) {
            return false;
        }

        return ((MultiProcCpu)cpu).pid == this.pid;
    }
}
